/**
 * Nexconn integration boundary.
 *
 * IMPORTANT: This starter intentionally does not invent SDK method names.
 * Follow the current Nexconn Web Chat SDK documentation/sample to implement
 * initialization, token retrieval, channel operations, history and events.
 */
export async function getNexconnConfig() {
  const appKey = import.meta.env.VITE_NEXCONN_APP_KEY;
  if (!appKey) throw new Error('Missing VITE_NEXCONN_APP_KEY in .env');
  const response = await fetch('/api/nexconn/token', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ userId: 'demo-user' })
  });
  if (!response.ok) throw new Error('Could not obtain Nexconn user token from backend.');
  const { token } = await response.json();
  if (!token) throw new Error('Token endpoint returned no token.');
  return { appKey, token };
}
